IMPORTANT!!!

** It is safe ** to remove the folders of the unused shools.  For examples, for FCT-UNL, you may delete all the folders inside the "Schools" folder except "unl/fct".