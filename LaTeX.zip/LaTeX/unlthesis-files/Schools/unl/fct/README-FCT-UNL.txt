%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% FCT-UNL
%% Faculdade de Ciências e Tecnologia
%% Universidade NOVA de Lisboa
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Reccomendations of options to be set/changed in “template.tex”:

  school=unl/fct,
  coverlang=pt,
	biblatex={
		…,
		style=numeric, % or any other… depends a lot on the degree!!!
		…,
	},

